import csv
import datetime
from statistics import median

def group_monthly(data, timestamp_col, group_cols, count_col, median_col):
    monthly_data = {}

    for row in data:
        timestamp = int(row[timestamp_col])
        date = datetime.datetime.fromtimestamp(timestamp).date()
        month = (date.year, date.month)

        if month not in monthly_data:
            monthly_data[month] = {}

        group_key = tuple(row[i] for i in group_cols)

        if group_key not in monthly_data[month]:
            monthly_data[month][group_key] = {
                'count': 0,
                'median': []
            }

        monthly_data[month][group_key]['count'] += 1
        monthly_data[month][group_key]['median'].append(float(row[median_col]))

    return monthly_data

def write_to_csv(monthly_data, filename):
    with open(filename, 'w', newline='') as f:
        writer = csv.writer(f)

        headers = ['Year', 'Month'] + list(group_cols) + ['Count', 'Median']
        metric = "" 
        writer.writerow(headers)

        for (year, month), groups in monthly_data.items():
            for group, data in groups.items():
                writer.writerow([year, month] + list(group) + [data['count'], median(data['median'])])

with open('problem.csv') as f:
    reader = csv.reader(f)
    headers = next(reader)

    timestamp_col = headers.index('starttime')
    group_cols = [headers.index(col) for col in ['management.zone', 'problem.title']]
    count_col = headers.index('problem.title')
    median_col = headers.index('mttr')

    data = list(reader)
    monthly_data = group_monthly(data, timestamp_col, group_cols, count_col, median_col)
    print(monthly_data)
    write_to_csv(monthly_data, 'output.csv')

