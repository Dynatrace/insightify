# Time in mins - timeframe after which the extension will gather metric for each of the section as defined below.
COLLECT_CONSUMPTION_DATA=60
COLLECT_PROBLEM_DATA=1440
COLLECT_FF_DATA=10080

# Problem = Incident 
#Time in ms - when problem is seen opened for the configured time below, treat it as incident. Default is 30 mins
PROBLEM_INCIDENT=1800000
